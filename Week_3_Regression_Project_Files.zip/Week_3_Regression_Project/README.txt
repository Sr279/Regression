# Week 3 Regression Project
## House Price Prediction Using Multiple Linear Regression

### Project objective
Build a regression model that predicts a continuous numerical value (house price)
from house area, number of bedrooms, house age, and distance to the city.

### Files included
- `Week_3_Regression_Project_Report.pdf` — detailed project report.
- `regression_project.py` — complete Python implementation.
- `house_price_sample_data.csv` — 300 simulated sample records.
- `Week_3_Regression_Project.ipynb` — Jupyter/Google Colab notebook.
- `requirements.txt` — Python libraries required.

### How to run in Google Colab
1. Open https://colab.research.google.com/
2. Upload `Week_3_Regression_Project.ipynb`.
3. Upload `house_price_sample_data.csv` into the Colab session.
4. Run the notebook cells from top to bottom.

### How to run on a computer
1. Install Python 3.
2. Open a terminal in this folder.
3. Install packages: `pip install -r requirements.txt`
4. Run: `python regression_project.py`

### Evaluation metrics
- MAE: Mean Absolute Error; average absolute prediction error.
- RMSE: Root Mean Squared Error; gives larger errors more weight.
- R-squared: proportion of target variation explained by the model on the test set.

### Important note
The dataset is simulated for learning and demonstration. The model is not a real
estate valuation system. Actual house prices depend on location, condition,
amenities, market demand, and many other factors.
