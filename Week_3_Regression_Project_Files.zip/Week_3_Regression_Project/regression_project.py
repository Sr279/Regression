# WEEK 3: REGRESSION PROJECT
# House Price Prediction using Multiple Linear Regression

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load the sample data file (keep it in the same folder as this script)
df = pd.read_csv("house_price_sample_data.csv")

# 1. Explore the dataset
print("First five rows:")
print(df.head())
print("\nDataset information:")
print(df.info())
print("\nMissing values:")
print(df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())

# 2. Select input features (X) and target (y)
X = df[["Area_sqft", "Bedrooms", "Age_years", "Distance_to_city_km"]]
y = df["House_Price"]

# 3. Split data: 80% training and 20% testing
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

# 4. Train the regression model
model = LinearRegression()
model.fit(X_train, y_train)

# 5. Make predictions on test data
y_pred = model.predict(X_test)

# 6. Evaluate the model
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("\nMODEL EVALUATION")
print(f"MAE: Rs. {mae:,.2f}")
print(f"RMSE: Rs. {rmse:,.2f}")
print(f"R-squared: {r2:.4f}")

# 7. Display the intercept and coefficients
print("\nMODEL COEFFICIENTS")
print(f"Intercept: Rs. {model.intercept_:,.2f}")
for feature, coefficient in zip(X.columns, model.coef_):
    print(f"{feature}: {coefficient:,.2f}")

# 8. Actual vs predicted graph
plt.figure(figsize=(7, 5))
plt.scatter(y_test, y_pred, alpha=0.7)
low = min(y_test.min(), y_pred.min())
high = max(y_test.max(), y_pred.max())
plt.plot([low, high], [low, high], "--")
plt.xlabel("Actual house price (Rs.)")
plt.ylabel("Predicted house price (Rs.)")
plt.title("Actual vs Predicted House Prices")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.show()

# 9. Residual plot
residuals = y_test - y_pred
plt.figure(figsize=(7, 5))
plt.scatter(y_pred, residuals, alpha=0.7)
plt.axhline(0, linestyle="--")
plt.xlabel("Predicted house price (Rs.)")
plt.ylabel("Residual (actual - predicted)")
plt.title("Residual Plot")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("residual_plot.png", dpi=150)
plt.show()

# 10. Predict the price of a new example house
new_house = pd.DataFrame({
    "Area_sqft": [1500],
    "Bedrooms": [3],
    "Age_years": [5],
    "Distance_to_city_km": [8.0]
})
predicted_price = model.predict(new_house)[0]
print(f"\nPredicted price for the example house: Rs. {predicted_price:,.2f}")

# IMPORTANT:
# This is an educational model trained on simulated sample data.
# Do not use it as a real property valuation tool.
